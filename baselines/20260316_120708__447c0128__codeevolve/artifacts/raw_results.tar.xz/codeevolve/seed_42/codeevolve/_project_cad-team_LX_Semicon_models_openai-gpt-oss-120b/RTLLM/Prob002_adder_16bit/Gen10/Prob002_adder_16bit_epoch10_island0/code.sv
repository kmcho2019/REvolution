module adder_8bit (
    input  [7:0] a,
    input  [7:0] b,
    input        Cin,
    output [7:0] sum,
    output       Cout
);
    // Simple combinational addition using carry‑out assignment
    assign {Cout, sum} = a + b + Cin;
endmodule

module adder_16bit (
    input  [15:0] a,
    input  [15:0] b,
    input         Cin,
    output [15:0] y,
    output        Co
);
    // Internal carry between the two 8‑bit blocks
    wire carry_mid;

    // Lower 8 bits
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8 bits
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule