`timescale 1ns/1ps
`default_nettype none

// ------------------------------------------------------------
// 4‑bit combinational full adder (uses vector addition)
// ------------------------------------------------------------
module adder_4bit (
    input  logic [3:0] a,
    input  logic [3:0] b,
    input  logic       Cin,
    output logic [3:0] sum,
    output logic       Cout
);
    // Perform addition; carry‑out is the MSB of the 5‑bit result
    assign {Cout, sum} = a + b + Cin;
endmodule

// ------------------------------------------------------------
// 8‑bit combinational full adder built from two 4‑bit adders
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Carry between the lower and upper 4‑bit halves
    logic carry_mid;

    // Lower 4 bits (bits 3:0)
    adder_4bit u_low (
        .a   (a[3:0]),
        .b   (b[3:0]),
        .Cin (Cin),
        .sum (y[3:0]),
        .Cout(carry_mid)
    );

    // Upper 4 bits (bits 7:4)
    adder_4bit u_high (
        .a   (a[7:4]),
        .b   (b[7:4]),
        .Cin (carry_mid),
        .sum (y[7:4]),
        .Cout(Co)
    );
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper 8‑bit slices
    logic carry_mid;

    // Lower byte (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper byte (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule