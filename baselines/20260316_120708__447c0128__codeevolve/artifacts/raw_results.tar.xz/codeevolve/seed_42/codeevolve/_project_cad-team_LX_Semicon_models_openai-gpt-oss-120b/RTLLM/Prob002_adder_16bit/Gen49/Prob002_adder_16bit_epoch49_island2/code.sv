`default_nettype none

// -----------------------------------------------------------------------------
// 1‑bit full adder implemented with primitive gates (XOR, AND, OR)
// -----------------------------------------------------------------------------
module full_adder (
    input  logic a,
    input  logic b,
    input  logic cin,
    output logic sum,
    output logic cout
);
    // Intermediate signals for XOR of a and b
    wire xor_ab;
    xor (xor_ab, a, b);
    xor (sum, xor_ab, cin);

    // Carry generation using three 2‑input AND gates and a 3‑input OR
    wire and_ab, and_ac, and_bc;
    and (and_ab, a, b);
    and (and_ac, a, cin);
    and (and_bc, b, cin);
    or  (cout, and_ab, and_ac, and_bc);
endmodule

// -----------------------------------------------------------------------------
// 8‑bit ripple‑carry adder built from eight full_adder cells
// -----------------------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       cin,
    output logic [7:0] sum,
    output logic       cout
);
    // Carry chain: carry[0] is the input carry, carry[8] is the final carry‑out
    logic [8:0] carry;
    assign carry[0] = cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : gen_fa
            full_adder u_fa (
                .a   (a[i]),
                .b   (b[i]),
                .cin (carry[i]),
                .sum (sum[i]),
                .cout(carry[i+1])
            );
        end
    endgenerate

    assign cout = carry[8];
endmodule

// -----------------------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit adders
// -----------------------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry from the lower byte to the upper byte
    logic carry_low;

    // Lower 8‑bit slice
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .cin (Cin),
        .sum (y[7:0]),
        .cout(carry_low)
    );

    // Upper 8‑bit slice
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .cin (carry_low),
        .sum (y[15:8]),
        .cout(Co)
    );
endmodule