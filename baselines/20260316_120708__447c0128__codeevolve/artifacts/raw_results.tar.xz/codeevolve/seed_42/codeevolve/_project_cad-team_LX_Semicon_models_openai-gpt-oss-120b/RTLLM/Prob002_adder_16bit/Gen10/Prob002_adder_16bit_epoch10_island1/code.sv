// 8‑bit combinational full adder
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Simple carry‑propagate addition using the Verilog '+' operator
    assign {Cout, sum} = a + b + Cin;
endmodule

// 16‑bit full adder built from two 8‑bit adders
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Low‑order byte
    wire [7:0] sum_low;
    wire       carry_low;
    
    // High‑order byte
    wire [7:0] sum_high;
    
    // Instantiate lower 8‑bit adder (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (sum_low),
        .Cout(carry_low)
    );
    
    // Instantiate upper 8‑bit adder (bits 15:8) with carry from lower block
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (sum_high),
        .Cout(Co)
    );
    
    // Concatenate the two partial sums
    assign y = {sum_high, sum_low};
endmodule