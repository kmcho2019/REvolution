// -----------------------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adder blocks
// -----------------------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // One‑shot combinational addition; the carry out is the MSB of the 9‑bit result
    assign {Cout, sum} = a + b + Cin;
endmodule

// -----------------------------------------------------------------------------
// Top‑level 16‑bit adder using two instances of the 8‑bit block
// -----------------------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Lower 8‑bit slice
    logic low_carry;
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(low_carry)
    );

    // Upper 8‑bit slice – carries in the carry from the lower slice
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (low_carry),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule