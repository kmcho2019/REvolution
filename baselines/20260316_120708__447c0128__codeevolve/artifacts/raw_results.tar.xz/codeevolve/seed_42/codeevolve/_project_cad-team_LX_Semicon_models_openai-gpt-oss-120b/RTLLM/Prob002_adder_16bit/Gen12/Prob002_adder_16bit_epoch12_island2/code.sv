// 1‑bit full adder – gate level implementation for low power/area
module full_adder (
    input  logic a,
    input  logic b,
    input  logic cin,
    output logic sum,
    output logic cout
);
    // Sum: a ^ b ^ cin
    assign sum  = a ^ b ^ cin;
    // Carry out: (a & b) | (a & cin) | (b & cin)
    assign cout = (a & b) | (a & cin) | (b & cin);
endmodule

// 8‑bit ripple‑carry adder built from the gate‑level full_adder
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       cin,
    output logic [7:0] sum,
    output logic       cout
);
    // Internal carry chain (one extra bit for final carry)
    logic [8:0] carry;
    assign carry[0] = cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : gen_fa
            full_adder u_fa (
                .a   (a[i]),
                .b   (b[i]),
                .cin (carry[i]),
                .sum (sum[i]),
                .cout(carry[i+1])
            );
        end
    endgenerate

    assign cout = carry[8];
endmodule

// 16‑bit adder that instantiates the 8‑bit adder twice
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry from lower half to upper half
    logic carry_low;

    // Lower 8‑bits
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .cin (Cin),
        .sum (y[7:0]),
        .cout(carry_low)
    );

    // Upper 8‑bits
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .cin (carry_low),
        .sum (y[15:8]),
        .cout(Co)
    );
endmodule