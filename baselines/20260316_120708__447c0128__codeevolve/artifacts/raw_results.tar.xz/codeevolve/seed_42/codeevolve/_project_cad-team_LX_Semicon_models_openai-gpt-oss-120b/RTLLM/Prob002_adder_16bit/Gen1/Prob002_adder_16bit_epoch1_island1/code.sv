// 8‑bit ripple‑carry adder (combinational)
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Simple combinational addition using Verilog's addition operator
    assign {Cout, sum} = a + b + Cin;
endmodule

// 16‑bit adder built from two 8‑bit adders
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the two 8‑bit blocks
    logic carry_mid;

    // Lower 8 bits
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8 bits
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule