`default_nettype none

// ---------------------------------------------------------------
// 8‑bit ripple‑carry adder (procedural implementation)
// ---------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Internal carry chain: c[0] = Cin, c[8] = final carry out
    logic [8:0] c;
    logic [7:0] sum;

    // Combinational logic to compute sum and carry
    always_comb begin
        c[0] = Cin;
        for (int i = 0; i < 8; i = i + 1) begin
            sum[i] = a[i] ^ b[i] ^ c[i];
            c[i+1] = (a[i] & b[i]) | (c[i] & (a[i] ^ b[i]));
        end
    end

    assign y  = sum;
    assign Co = c[8];
endmodule

// ---------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ---------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry link between the lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule