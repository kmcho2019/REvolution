`timescale 1ns/1ps
`default_nettype none

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder expressed with an always_comb block
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    logic [7:0] p;   // propagate
    logic [7:0] g;   // generate
    logic [8:0] c;   // carry chain, c[0] = Cin

    always_comb begin
        p = a ^ b;
        g = a & b;
        c[0] = Cin;
        for (int i = 0; i < 8; i = i + 1) begin
            c[i+1] = g[i] | (p[i] & c[i]);
        end
        sum  = p ^ c[7:0];
        Cout = c[8];
    end
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between lower and upper byte
    logic carry_low;

    // Lower 8‑bit block (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit block (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule