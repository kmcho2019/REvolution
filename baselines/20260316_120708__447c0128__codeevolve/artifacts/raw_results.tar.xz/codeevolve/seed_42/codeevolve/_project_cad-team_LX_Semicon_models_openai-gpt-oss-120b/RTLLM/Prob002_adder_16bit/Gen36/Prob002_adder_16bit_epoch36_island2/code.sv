// 8‑bit combinational full adder using vector addition
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // One‑line addition; synthesis will map to an efficient carry chain
    assign {Co, y} = a + b + Cin;
endmodule

// 16‑bit full adder built from two 8‑bit adders
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between lower and upper halves
    logic c_mid;

    // Lower 8 bits (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (c_mid)
    );

    // Upper 8 bits (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (c_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule