module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Carry vector: carry[0] = Cin, carry[8] = final carry out
    logic [8:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : BIT
            // Compute next carry and sum bit
            assign carry[i+1] = (a[i] & b[i]) | ((a[i] ^ b[i]) & carry[i]);
            assign y[i]       = a[i] ^ b[i] ^ carry[i];
        end
    endgenerate

    assign Co = carry[8];
endmodule

module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between the lower and upper byte
    logic carry_mid;

    genvar j;
    generate
        for (j = 0; j < 2; j = j + 1) begin : BYTE
            // Calculate slice base index
            localparam int lo = j * 8;
            adder_8bit u_inst (
                .a   (a[lo +: 8]),
                .b   (b[lo +: 8]),
                .Cin (j == 0 ? Cin : carry_mid),
                .y   (y[lo +: 8]),
                .Co  (j == 0 ? carry_mid : Co)
            );
        end
    endgenerate
endmodule