`timescale 1ns/1ps
`default_nettype none

// -------------------------------------------------------------------
// 8‑bit combinational full adder (behavioral, single driver)
// -------------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Intermediate result includes carry out
    logic [8:0] result;

    // Pure combinational logic – synthesizers will infer an efficient adder
    always_comb begin
        result = a + b + Cin;
        sum    = result[7:0];
        Cout   = result[8];
    end
endmodule

// -------------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders (generated instances)
// -------------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    localparam int BLOCK_W = 8;   // width of each sub‑adder
    localparam int NUM_BLOCK = 2; // number of 8‑bit blocks needed

    // Carry chain: carry[0] is the external Cin, carry[NUM_BLOCK] is the final Co
    logic [NUM_BLOCK:0] carry;
    assign carry[0] = Cin;
    assign Co       = carry[NUM_BLOCK];

    genvar i;
    generate
        for (i = 0; i < NUM_BLOCK; i = i + 1) begin : gen_adders
            adder_8bit u8 (
                .a   (a[i*BLOCK_W +: BLOCK_W]),
                .b   (b[i*BLOCK_W +: BLOCK_W]),
                .Cin (carry[i]),
                .sum (y[i*BLOCK_W +: BLOCK_W]),
                .Cout(carry[i+1])
            );
        end
    endgenerate
endmodule