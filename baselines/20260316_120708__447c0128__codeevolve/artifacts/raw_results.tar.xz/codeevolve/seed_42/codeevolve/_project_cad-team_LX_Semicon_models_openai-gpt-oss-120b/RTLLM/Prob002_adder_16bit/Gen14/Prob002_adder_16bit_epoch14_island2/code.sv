// ---------------------------------------------------------------------------
// 4‑bit Carry‑Lookahead Adder (CLA)
// ---------------------------------------------------------------------------
module cla_4bit (
    input  logic [3:0] a,
    input  logic [3:0] b,
    input  logic       cin,
    output logic [3:0] sum,
    output logic       cout
);
    // Propagate and Generate signals for each bit
    logic [3:0] p, g;
    assign p = a ^ b;          // propagate
    assign g = a & b;          // generate

    // Carry equations (combinational)
    logic c1, c2, c3, c4;
    assign c1 = g[0] | (p[0] & cin);
    assign c2 = g[1] | (p[1] & g[0]) | (p[1] & p[0] & cin);
    assign c3 = g[2] | (p[2] & g[1]) | (p[2] & p[1] & g[0]) | (p[2] & p[1] & p[0] & cin);
    assign c4 = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) |
                (p[3] & p[2] & p[1] & g[0]) | (p[3] & p[2] & p[1] & p[0] & cin);

    // Sum bits
    assign sum[0] = p[0] ^ cin;
    assign sum[1] = p[1] ^ c1;
    assign sum[2] = p[2] ^ c2;
    assign sum[3] = p[3] ^ c3;

    assign cout = c4;
endmodule

// ---------------------------------------------------------------------------
// 8‑bit adder built from two 4‑bit CLA blocks (carry‑select style)
// ---------------------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       cin,
    output logic [7:0] sum,
    output logic       cout
);
    // Lower 4 bits
    logic cout_low;
    cla_4bit u_low (
        .a   (a[3:0]),
        .b   (b[3:0]),
        .cin (cin),
        .sum (sum[3:0]),
        .cout(cout_low)
    );

    // Upper 4 bits
    cla_4bit u_high (
        .a   (a[7:4]),
        .b   (b[7:4]),
        .cin (cout_low),
        .sum (sum[7:4]),
        .cout(cout)
    );
endmodule

// ---------------------------------------------------------------------------
// 16‑bit adder composed of two 8‑bit adders
// ---------------------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Lower 8‑bit block
    logic carry_mid;
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .cin (Cin),
        .sum (y[7:0]),
        .cout(carry_mid)
    );

    // Upper 8‑bit block
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .cin (carry_mid),
        .sum (y[15:8]),
        .cout(Co)
    );
endmodule