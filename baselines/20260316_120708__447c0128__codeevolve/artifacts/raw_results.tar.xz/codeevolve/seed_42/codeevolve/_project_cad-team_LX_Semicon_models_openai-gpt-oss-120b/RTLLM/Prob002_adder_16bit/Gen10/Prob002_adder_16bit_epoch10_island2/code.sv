// 8‑bit combinational adder
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Simple arithmetic adds carry‑in; synthesis will infer ripple/parallel adder
    assign {Cout, sum} = a + b + Cin;
endmodule

// 16‑bit adder built from two 8‑bit adders
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Lower 8 bits
    logic c_mid;
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(c_mid)
    );

    // Upper 8 bits
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (c_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule