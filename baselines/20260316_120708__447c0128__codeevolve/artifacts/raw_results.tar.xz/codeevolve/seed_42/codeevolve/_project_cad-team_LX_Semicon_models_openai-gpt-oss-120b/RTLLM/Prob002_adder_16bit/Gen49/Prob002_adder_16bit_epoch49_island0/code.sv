`default_nettype none

// ---------------------------------------------------------------
// 8‑bit ripple‑carry full adder (procedural implementation)
// ---------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Internal carry variable used only inside the always_comb block
    logic carry;
    integer i;
    
    always_comb begin : ripple
        carry = Cin;
        for (i = 0; i < 8; i = i + 1) begin
            y[i]   = a[i] ^ b[i] ^ carry;
            carry  = (a[i] & b[i]) | (a[i] & carry) | (b[i] & carry);
        end
        Co = carry;
    end
endmodule

// ---------------------------------------------------------------
// 16‑bit full adder built by instantiating two 8‑bit adders
// ---------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between the lower and upper byte
    logic carry_mid;

    // Lower byte (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper byte (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule