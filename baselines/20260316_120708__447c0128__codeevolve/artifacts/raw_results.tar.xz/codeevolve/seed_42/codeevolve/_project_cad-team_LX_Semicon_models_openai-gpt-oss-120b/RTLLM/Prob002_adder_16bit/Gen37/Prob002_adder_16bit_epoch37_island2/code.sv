`default_nettype none

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (optimized carry expression)
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Internal carry chain (extra bit for final carry)
    logic [8:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : gen_bit
            // Sum bit
            assign y[i] = a[i] ^ b[i] ^ carry[i];
            // Optimized carry: generate or propagate & carry_in
            assign carry[i+1] = (a[i] & b[i]) | ((a[i] ^ b[i]) & carry[i]);
        end
    endgenerate

    assign Co = carry[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit blocks
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between lower and upper halves
    logic carry_mid;

    // Lower 8 bits (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8 bits (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule