`timescale 1ns/1ps

// ------------------------------------------------------------
// 1‑bit full adder (combinational)
// ------------------------------------------------------------
module adder_1bit (
    input  logic a,
    input  logic b,
    input  logic Cin,
    output logic sum,
    output logic Cout
);
    assign sum  = a ^ b ^ Cin;
    assign Cout = (a & b) | (a & Cin) | (b & Cin);
endmodule

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder built from eight 1‑bit adders
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Carry chain (c[0] is the incoming carry, c[8] is the final carry)
    logic [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : bit_adder
            adder_1bit u_fa (
                .a   (a[i]),
                .b   (b[i]),
                .Cin (c[i]),
                .sum (sum[i]),
                .Cout(c[i+1])
            );
        end
    endgenerate

    assign Cout = c[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder constructed from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Lower byte (bits 7:0)
    logic [7:0] sum_low;
    logic       carry_mid;
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (sum_low),
        .Cout(carry_mid)
    );

    // Upper byte (bits 15:8)
    logic [7:0] sum_high;
    logic       carry_high;
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (sum_high),
        .Cout(carry_high)
    );

    // Concatenate the two halves
    assign y  = {sum_high, sum_low};
    assign Co = carry_high;
endmodule