`timescale 1ns/1ps

// ------------------------------------------------------------
// 1‑bit full adder (combinational)
// ------------------------------------------------------------
module full_adder (
    input  logic a,
    input  logic b,
    input  logic Cin,
    output logic sum,
    output logic Cout
);
    // Sum = a xor b xor Cin
    // Carry = majority of (a,b,Cin)
    assign sum  = a ^ b ^ Cin;
    assign Cout = (a & b) | (a & Cin) | (b & Cin);
endmodule

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder built from full_adder cells
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Internal carry chain
    logic [8:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : fa_chain
            full_adder fa_inst (
                .a   (a[i]),
                .b   (b[i]),
                .Cin (carry[i]),
                .sum (sum[i]),
                .Cout(carry[i+1])
            );
        end
    endgenerate

    assign Cout = carry[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry from lower byte to upper byte
    logic carry_low;

    // Lower 8‑bit slice
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit slice
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule