// 8‑bit combinational full adder (single assign as required)
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // 9‑bit result provides carry‑out and sum bits
    assign {Cout, sum} = a + b + Cin;
endmodule

// 16‑bit full adder built from two 8‑bit adders using a generate loop
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between the lower and upper byte
    logic carry_mid;

    generate
        // Lower byte (bits 7:0)
        adder_8bit u_low (
            .a   (a[7:0]),
            .b   (b[7:0]),
            .Cin (Cin),
            .sum (y[7:0]),
            .Cout(carry_mid)
        );
        // Upper byte (bits 15:8)
        adder_8bit u_high (
            .a   (a[15:8]),
            .b   (b[15:8]),
            .Cin (carry_mid),
            .sum (y[15:8]),
            .Cout(Co)
        );
    endgenerate
endmodule