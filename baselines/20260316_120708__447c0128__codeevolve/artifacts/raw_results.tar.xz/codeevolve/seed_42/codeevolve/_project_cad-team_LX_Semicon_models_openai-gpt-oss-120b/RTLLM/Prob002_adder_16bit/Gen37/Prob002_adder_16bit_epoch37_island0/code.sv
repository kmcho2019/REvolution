`timescale 1ns/1ps
`default_nettype none

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (compact implementation)
// ------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Carry chain: c[0] = Cin, c[8] = final carry‑out
    wire [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : BIT
            // Sum bit
            assign sum[i] = a[i] ^ b[i] ^ c[i];
            // Carry to next stage (generate or propagate)
            assign c[i+1] = (a[i] & b[i]) | (c[i] & (a[i] ^ b[i]));
        end
    endgenerate

    assign Cout = c[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Intermediate carry between the lower and upper byte
    wire carry_mid;

    // Lower 8‑bit slice (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8‑bit slice (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule