`timescale 1ns/1ps
`default_nettype none

// ---------------------------------------------------------------
// 1‑bit full‑adder cell (leaf)
// ---------------------------------------------------------------
module full_adder_1bit (
    input  logic a,
    input  logic b,
    input  logic cin,
    output logic sum,
    output logic cout
);
    // Sum = a ^ b ^ cin
    assign sum  = a ^ b ^ cin;
    // Carry-out = (a & b) | (cin & (a ^ b))
    assign cout = (a & b) | (cin & (a ^ b));
endmodule

// ---------------------------------------------------------------
// 8‑bit ripple‑carry adder built from eight 1‑bit cells
// ---------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Carry chain: carry[0] is the incoming Cin, carry[8] is Co
    logic [8:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : FA_CHAIN
            full_adder_1bit u_fa (
                .a   (a[i]),
                .b   (b[i]),
                .cin (carry[i]),
                .sum (y[i]),
                .cout(carry[i+1])
            );
        end
    endgenerate

    assign Co = carry[8];
endmodule

// ---------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit adders as required
// ---------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between the lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule