`timescale 1ns / 1ps

// ------------------------------------------------------------
// 8‑bit combinational full adder
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0]  a,
    input  logic [7:0]  b,
    input  logic        Cin,
    output logic [7:0]  sum,
    output logic        Cout
);
    // The addition is performed in one statement; synthesis will map to a ripple‑carry or fast adder.
    assign {Cout, sum} = a + b + Cin;
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Wires for the carry between the two 8‑bit blocks
    logic carry_mid;

    // Lower 8‑bit addition (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8‑bit addition (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule