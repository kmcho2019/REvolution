`timescale 1ns/1ps
`default_nettype none

// -------------------------------------------------------------------
// 8‑bit ripple‑carry adder (propagate/generate implementation)
// -------------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Local constant for width
    localparam int W = 8;

    // Propagate and generate vectors
    logic [W-1:0] p = a ^ b;   // propagate = a ^ b
    logic [W-1:0] g = a & b;   // generate  = a & b

    // Carry chain: c[0] = Cin, c[W] = final carry‑out
    logic [W:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < W; i = i + 1) begin : bit_stage
            // Carry to next stage
            assign c[i+1] = g[i] | (p[i] & c[i]);
            // Sum bit
            assign y[i]   = p[i] ^ c[i];
        end
    endgenerate

    assign Co = c[W];
endmodule

// -------------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// -------------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8‑bit slice (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule