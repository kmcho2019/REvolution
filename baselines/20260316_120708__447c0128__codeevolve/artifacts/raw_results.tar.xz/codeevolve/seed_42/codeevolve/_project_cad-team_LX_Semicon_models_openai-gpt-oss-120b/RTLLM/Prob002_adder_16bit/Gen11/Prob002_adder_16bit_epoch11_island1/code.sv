`timescale 1ns/1ps

// ------------------------------------------------------------
// 1‑bit full‑adder cell (combinational)
// ------------------------------------------------------------
module full_adder_1bit (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    // Sum is XOR of all three inputs
    assign sum  = a ^ b ^ cin;
    // Carry‑out generation
    assign cout = (a & b) | (a & cin) | (b & cin);
endmodule

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder built from the 1‑bit cells
// ------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Internal carry vector (9 bits: carry[0] is Cin, carry[8] is Cout)
    wire [8:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : FA_CHAIN
            full_adder_1bit u_fa (
                .a   (a[i]),
                .b   (b[i]),
                .cin (carry[i]),
                .sum (sum[i]),
                .cout(carry[i+1])
            );
        end
    endgenerate

    assign Cout = carry[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Lower byte (bits 7:0)
    wire [7:0] sum_low;
    wire       carry_low;
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (sum_low),
        .Cout(carry_low)
    );

    // Upper byte (bits 15:8)
    wire [7:0] sum_high;
    wire       carry_high;
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (sum_high),
        .Cout(carry_high)
    );

    assign y  = {sum_high, sum_low};
    assign Co = carry_high;
endmodule