`default_nettype none

// ------------------------------------------------------------
// 1‑bit full adder (gate‑level implementation)
// ------------------------------------------------------------
module full_adder (
    input  logic a,
    input  logic b,
    input  logic cin,
    output logic sum,
    output logic cout
);
    // Sum: XOR of all three inputs
    assign sum  = a ^ b ^ cin;
    // Carry out: majority function
    assign cout = (a & b) | (a & cin) | (b & cin);
endmodule

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder using the 1‑bit full_adder
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Internal carry chain (9 bits: carry[0] is Cin, carry[8] is final carry)
    logic [8:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : GEN_FA
            full_adder u_fa (
                .a   (a[i]),
                .b   (b[i]),
                .cin (carry[i]),
                .sum (sum[i]),
                .cout(carry[i+1])
            );
        end
    endgenerate

    assign Cout = carry[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry from lower byte to upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule