`timescale 1ns/1ps

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (procedural implementation)
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Internal carry vector (c[0] is Cin, c[8] is final carry)
    logic [8:0] c;
    integer i;

    // Combinational logic to compute carries and sum bits
    always_comb begin
        c[0] = Cin;
        for (i = 0; i < 8; i = i + 1) begin
            sum[i] = a[i] ^ b[i] ^ c[i];
            c[i+1] = (a[i] & b[i]) | (c[i] & (a[i] ^ b[i]));
        end
        Cout = c[8];
    end
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry from the lower byte to the upper byte
    logic carry_low;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule