`timescale 1ns/1ps

// ------------------------------------------------------------
// 1‑bit full adder (combinational)
// ------------------------------------------------------------
module full_adder1 (
    input  wire a,
    input  wire b,
    input  wire Cin,
    output wire sum,
    output wire Cout
);
    assign sum  = a ^ b ^ Cin;
    assign Cout = (a & b) | (a & Cin) | (b & Cin);
endmodule

// ------------------------------------------------------------
// 8‑bit adder built from eight 1‑bit full adders
// ------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Carry chain: c[0] is the external Cin, c[8] is the final carry
    wire [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : gen_fa
            full_adder1 u_fa (
                .a   (a[i]),
                .b   (b[i]),
                .Cin (c[i]),
                .sum (sum[i]),
                .Cout(c[i+1])
            );
        end
    endgenerate

    assign Cout = c[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Carry from lower byte to upper byte
    wire carry_low;

    // Lower 8‑bit adder drives the lower slice of the result
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit adder drives the upper slice of the result
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule