// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (gate‑level, re‑using propagate XOR)
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       cin,
    output logic [7:0] sum,
    output logic       cout
);
    // Carry chain (9 bits to hold final carry)
    logic [8:0] carry;
    assign carry[0] = cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : gen_bit
            // Propagate term (a ^ b) – computed once and re‑used
            logic p;
            assign p       = a[i] ^ b[i];
            // Sum bit
            assign sum[i]  = p ^ carry[i];
            // Carry out: generate OR (carry) using propagate term
            assign carry[i+1] = (a[i] & b[i]) | (carry[i] & p);
        end
    endgenerate

    assign cout = carry[8];
endmodule

// ------------------------------------------------------------
// 16‑bit adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry from lower half to upper half
    logic carry_low;

    // Lower 8 bits
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .cin (Cin),
        .sum (y[7:0]),
        .cout(carry_low)
    );

    // Upper 8 bits
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .cin (carry_low),
        .sum (y[15:8]),
        .cout(Co)
    );
endmodule