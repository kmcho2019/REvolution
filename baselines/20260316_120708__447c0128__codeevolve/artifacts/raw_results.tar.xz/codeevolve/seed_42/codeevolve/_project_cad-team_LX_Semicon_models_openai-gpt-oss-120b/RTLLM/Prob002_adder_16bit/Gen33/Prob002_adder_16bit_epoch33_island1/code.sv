`timescale 1ns/1ps
`default_nettype none

// -----------------------------------------------------------------------------
// 8‑bit ripple‑carry adder implemented with a single addition expression.
// This style lets the synthesis tool infer an optimized adder, improving PPA.
// -----------------------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // 9‑bit temporary vector holds the full addition result.
    logic [8:0] tmp;
    assign tmp = {1'b0, a} + {1'b0, b} + Cin;
    assign sum = tmp[7:0];
    assign Cout = tmp[8];
endmodule

// -----------------------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders as required by the specification.
// -----------------------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8‑bit slice (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule