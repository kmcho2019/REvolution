`timescale 1ns/1ps
`default_nettype none

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (procedural always_comb implementation)
// ------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] y,
    output wire       Co
);
    // Internal carry vector (c[0] = Cin, c[8] = final carry‑out)
    logic [8:0] c;
    // Procedural combinational block computes carries and sum bits
    always_comb begin : proc_ripple
        c[0] = Cin;
        for (int i = 0; i < 8; i = i + 1) begin
            // Sum bit
            y[i] = a[i] ^ b[i] ^ c[i];
            // Next carry: g = a&b, p = a^b
            c[i+1] = (a[i] & b[i]) | ((a[i] ^ b[i]) & c[i]);
        end
    end
    // Final carry‑out
    assign Co = c[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Carry between the two 8‑bit slices
    wire carry_mid;

    // Lower byte (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper byte (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule