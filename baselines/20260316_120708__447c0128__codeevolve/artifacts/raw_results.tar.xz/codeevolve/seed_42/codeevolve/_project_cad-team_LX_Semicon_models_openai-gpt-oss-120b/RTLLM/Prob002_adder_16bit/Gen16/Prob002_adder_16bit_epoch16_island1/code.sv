`timescale 1ns/1ps

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (combinational, propagate/generate)
// ------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Propagate and generate signals
    wire [7:0] p = a ^ b; // propagate
    wire [7:0] g = a & b; // generate

    // Carry chain (c[0] = Cin, c[8] = final carry)
    wire [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : carry_chain
            assign c[i+1] = g[i] | (p[i] & c[i]);
        end
    endgenerate

    // Sum bits
    assign sum  = p ^ c[7:0];
    assign Cout = c[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Carry between lower and upper byte
    wire carry_low;

    // Lower 8‑bit block drives bits 7:0 of the result
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit block drives bits 15:8 of the result
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule