`default_nettype none

// ---------------------------------------------------------------------
// 8‑bit combinational full adder (uses a single arithmetic assignment).
// ---------------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Concatenate carry‑out with the 8‑bit sum.
    assign {Co, y} = a + b + Cin;
endmodule

// ---------------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders as required.
// ---------------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between lower and upper byte.
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7).
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15).
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule