`default_nettype none

// ---------------------------------------------------------------
// 8‑bit combinational ripple‑carry adder
// ---------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Internal carry chain (carry[0] is the input carry)
    logic [7:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : BIT_ADD
            // Sum bit
            assign sum[i] = a[i] ^ b[i] ^ carry[i];
            if (i == 7) begin
                // Final carry‑out
                assign Cout = (a[i] & b[i]) | (a[i] & carry[i]) | (b[i] & carry[i]);
            end else begin
                // Propagate carry to next stage
                assign carry[i+1] = (a[i] & b[i]) | (a[i] & carry[i]) | (b[i] & carry[i]);
            end
        end
    endgenerate
endmodule

// ---------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ---------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule