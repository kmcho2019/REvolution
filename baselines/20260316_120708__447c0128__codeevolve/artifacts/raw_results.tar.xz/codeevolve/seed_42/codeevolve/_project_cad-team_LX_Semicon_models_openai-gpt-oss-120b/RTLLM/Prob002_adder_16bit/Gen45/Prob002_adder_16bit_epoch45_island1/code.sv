// 8‑bit combinational full adder (provided snippet)
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] y,
    output wire       Co
);
    // Vector addition; synthesis will map to an efficient carry chain
    assign {Co, y} = a + b + Cin;
endmodule

// 16‑bit full adder built from two 8‑bit adders
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Intermediate carry between the low and high 8‑bit blocks
    wire c_mid;

    // Lower 8 bits (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (c_mid)
    );

    // Upper 8 bits (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (c_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule