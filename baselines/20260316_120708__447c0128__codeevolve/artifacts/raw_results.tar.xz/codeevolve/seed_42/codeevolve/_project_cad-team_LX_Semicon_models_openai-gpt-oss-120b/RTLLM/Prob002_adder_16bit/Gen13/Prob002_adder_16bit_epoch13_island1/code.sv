`timescale 1ns/1ps

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (combinational, propagate/generate)
// ------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Propagate and generate signals
    wire [7:0] p = a ^ b;  // propagate
    wire [7:0] g = a & b;  // generate

    // Carry chain (c[0] = Cin, c[8] = final carry)
    wire [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : carry_chain
            // c[i+1] = g[i] | (p[i] & c[i])
            assign c[i+1] = g[i] | (p[i] & c[i]);
        end
    endgenerate

    // Sum bits
    assign sum  = p ^ c[7:0];
    assign Cout = c[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Lower byte (bits 7:0)
    wire [7:0] sum_low;
    wire       carry_low;
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (sum_low),
        .Cout(carry_low)
    );

    // Upper byte (bits 15:8)
    wire [7:0] sum_high;
    wire       carry_high;
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (sum_high),
        .Cout(carry_high)
    );

    // Concatenate results
    assign y  = {sum_high, sum_low};
    assign Co = carry_high;
endmodule