`default_nettype none

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (compact CLA without extra p/g vectors)
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Carry chain (c[0] = Cin, c[8] = final carry out)
    logic [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : bit_stage
            // Sum bit: a ^ b ^ carry_in
            assign sum[i] = a[i] ^ b[i] ^ c[i];
            // Carry out: generate or propagate & carry_in
            assign c[i+1] = (a[i] & b[i]) | ((a[i] ^ b[i]) & c[i]);
        end
    endgenerate

    assign Cout = c[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper 8‑bit blocks
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule