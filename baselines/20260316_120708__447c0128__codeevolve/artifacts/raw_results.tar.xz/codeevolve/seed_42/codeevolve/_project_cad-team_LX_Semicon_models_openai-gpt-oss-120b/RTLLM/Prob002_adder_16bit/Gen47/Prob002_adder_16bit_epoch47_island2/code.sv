// ------------------------------------------------------------
// 8‑bit ripple‑carry adder – gate‑level implementation
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       cin,
    output logic [7:0] sum,
    output logic       cout
);
    // Carry chain (one extra bit for final carry)
    logic [8:0] carry;
    assign carry[0] = cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : bit_slice
            // Sum bit: a ^ b ^ carry_in
            assign sum[i] = a[i] ^ b[i] ^ carry[i];
            // Carry out: (a & b) | (a & carry_in) | (b & carry_in)
            assign carry[i+1] = (a[i] & b[i]) | (a[i] & carry[i]) | (b[i] & carry[i]);
        end
    endgenerate

    assign cout = carry[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry from lower byte to upper byte
    logic carry_mid;

    // Lower 8 bits (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .cin (Cin),
        .sum (y[7:0]),
        .cout(carry_mid)
    );

    // Upper 8 bits (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .cin (carry_mid),
        .sum (y[15:8]),
        .cout(Co)
    );
endmodule