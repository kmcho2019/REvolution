`timescale 1ns/1ps

// 1‑bit full adder cell
module adder_1bit (
    input  wire a,
    input  wire b,
    input  wire Cin,
    output wire sum,
    output wire Cout
);
    assign sum  = a ^ b ^ Cin;
    assign Cout = (a & b) | (a & Cin) | (b & Cin);
endmodule

// 8‑bit ripple‑carry adder composed of 1‑bit cells
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    wire [8:0] c; // carry chain, c[0] = Cin, c[8] = final carry
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : fa_block
            adder_1bit u_fa (
                .a   (a[i]),
                .b   (b[i]),
                .Cin (c[i]),
                .sum (sum[i]),
                .Cout(c[i+1])
            );
        end
    endgenerate

    assign Cout = c[8];
endmodule

// 16‑bit full adder built from two 8‑bit adders
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Carry from lower byte to upper byte
    wire carry_low;

    // Lower 8‑bit slice (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit slice (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule