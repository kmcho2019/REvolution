`timescale 1ns/1ps
`default_nettype none

// ------------------------------------------------------------
// 4‑bit ripple‑carry adder (propagate/generate style)
// ------------------------------------------------------------
module adder_4bit (
    input  logic [3:0] a,
    input  logic [3:0] b,
    input  logic       Cin,
    output logic [3:0] y,
    output logic       Co
);
    // Carry chain: c[0] = Cin, c[4] = final carry‑out
    logic [4:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : bit_stage
            // Sum bit
            assign y[i] = a[i] ^ b[i] ^ c[i];
            // Carry to next stage (g = a&b, p = a^b)
            assign c[i+1] = (a[i] & b[i]) | ((a[i] ^ b[i]) & c[i]);
        end
    endgenerate

    assign Co = c[4];
endmodule

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder built from two 4‑bit adders
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Intermediate carry between the two 4‑bit slices
    logic carry_mid;

    // Lower 4‑bit slice (bits 3:0)
    adder_4bit u_low (
        .a   (a[3:0]),
        .b   (b[3:0]),
        .Cin (Cin),
        .y   (y[3:0]),
        .Co  (carry_mid)
    );

    // Upper 4‑bit slice (bits 7:4)
    adder_4bit u_high (
        .a   (a[7:4]),
        .b   (b[7:4]),
        .Cin (carry_mid),
        .y   (y[7:4]),
        .Co  (Co)
    );
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper 8‑bit blocks
    logic carry_mid;

    // Lower 8‑bit slice (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8‑bit slice (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule