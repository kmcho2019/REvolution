`timescale 1ns/1ps

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (pure combinational)
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Carry chain: c[0] is Cin, c[8] is final carry out
    logic [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : ripple
            // Carry generate for bit i
            assign c[i+1] = (a[i] & b[i]) | ((a[i] ^ b[i]) & c[i]);
            // Sum for bit i
            assign sum[i] = a[i] ^ b[i] ^ c[i];
        end
    endgenerate

    assign Cout = c[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry from lower byte to upper byte
    logic carry_low;

    // Lower 8‑bit block (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit block (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule