// 1‑bit full adder
module full_adder (
    input  logic a,
    input  logic b,
    input  logic cin,
    output logic sum,
    output logic cout
);
    // Simple combinational addition using concatenation
    assign {cout, sum} = a + b + cin;
endmodule

// 8‑bit ripple‑carry adder built from full_adder instances
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       cin,
    output logic [7:0] sum,
    output logic       cout
);
    logic [7:0] carry;
    assign carry[0] = cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : gen_fa
            if (i == 7) begin
                // Final stage drives the module carry‑out
                full_adder fa_inst (
                    .a   (a[i]),
                    .b   (b[i]),
                    .cin (carry[i]),
                    .sum (sum[i]),
                    .cout (cout)
                );
            end else begin
                // Intermediate stage forwards carry to the next bit
                full_adder fa_inst (
                    .a   (a[i]),
                    .b   (b[i]),
                    .cin (carry[i]),
                    .sum (sum[i]),
                    .cout (carry[i+1])
                );
            end
        end
    endgenerate
endmodule

// 16‑bit adder that re‑uses the 8‑bit adder twice
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    logic carry_low;

    // Lower 8 bits
    adder_8bit low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .cin (Cin),
        .sum (y[7:0]),
        .cout(carry_low)
    );

    // Upper 8 bits, carries from lower block
    adder_8bit high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .cin (carry_low),
        .sum (y[15:8]),
        .cout(Co)
    );
endmodule