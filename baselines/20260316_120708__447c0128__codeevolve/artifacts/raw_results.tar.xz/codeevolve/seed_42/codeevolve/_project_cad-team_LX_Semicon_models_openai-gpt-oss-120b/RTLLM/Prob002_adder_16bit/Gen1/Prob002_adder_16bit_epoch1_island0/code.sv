// 8‑bit combinational adder used as a building block
module adder_8bit (
    input  [7:0] a,
    input  [7:0] b,
    input        Cin,
    output [7:0] y,
    output       Co
);
    // 9‑bit result captures sum and carry‑out
    wire [8:0] result;
    assign result = a + b + Cin;
    assign y = result[7:0];
    assign Co = result[8];
endmodule

// 16‑bit full adder built by cascading two 8‑bit adders
module adder_16bit (
    input  [15:0] a,
    input  [15:0] b,
    input         Cin,
    output [15:0] y,
    output        Co
);
    // lower 8 bits
    wire [7:0] sum_low;
    wire       carry_low;

    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (sum_low),
        .Co  (carry_low)
    );

    // upper 8 bits
    wire [7:0] sum_high;
    wire       carry_high;

    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .y   (sum_high),
        .Co  (carry_high)
    );

    assign y  = {sum_high, sum_low};
    assign Co = carry_high;
endmodule