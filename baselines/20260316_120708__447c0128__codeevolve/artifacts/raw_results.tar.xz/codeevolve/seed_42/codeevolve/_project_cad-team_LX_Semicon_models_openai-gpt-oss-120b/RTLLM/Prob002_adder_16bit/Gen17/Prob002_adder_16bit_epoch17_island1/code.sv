`timescale 1ns/1ps
`default_nettype none

// ------------------------------------------------------------
// 1‑bit full‑adder (structural, using addition operator)
// ------------------------------------------------------------
module full_adder_1bit (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    // Vector addition infers the minimal carry logic for a single bit
    assign {cout, sum} = a + b + cin;
endmodule

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder built from 1‑bit full adders
// ------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Internal carry chain (carry[0] is Cin, carry[8] is final carry)
    wire [8:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : FA_CHAIN
            full_adder_1bit u_fa (
                .a   (a[i]),
                .b   (b[i]),
                .cin (carry[i]),
                .sum (sum[i]),
                .cout(carry[i+1])
            );
        end
    endgenerate

    assign Cout = carry[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Carry between lower and upper byte
    wire carry_low;

    // Lower 8‑bit block drives bits 7:0 of the result
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit block drives bits 15:8 of the result
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule