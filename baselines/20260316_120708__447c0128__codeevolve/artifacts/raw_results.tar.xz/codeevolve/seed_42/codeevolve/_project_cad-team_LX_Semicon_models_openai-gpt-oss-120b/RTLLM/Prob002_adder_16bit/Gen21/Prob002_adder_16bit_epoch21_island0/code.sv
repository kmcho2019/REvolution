`default_nettype none

// ---------------------------------------------------------------
// Generic N‑bit ripple‑carry adder (parameterizable)
// ---------------------------------------------------------------
module adder_nbit #(parameter int N = 8) (
    input  logic [N-1:0] a,
    input  logic [N-1:0] b,
    input  logic         Cin,
    output logic [N-1:0] y,
    output logic         Co
);
    // Carry vector: c[0] is the input carry, c[N] is the final carry‑out
    logic [N:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : GEN_ADDER
            // Carry generation for bit i
            assign c[i+1] = (a[i] & b[i]) | ((a[i] ^ b[i]) & c[i]);
            // Sum bit i
            assign y[i]   = a[i] ^ b[i] ^ c[i];
        end
    endgenerate

    assign Co = c[N];
endmodule

// ---------------------------------------------------------------
// 8‑bit adder required by the problem statement (thin wrapper)
// ---------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Instantiate the generic adder with N=8
    adder_nbit #(.N(8)) u_adder (
        .a   (a),
        .b   (b),
        .Cin (Cin),
        .y   (y),
        .Co  (Co)
    );
endmodule

// ---------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ---------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule