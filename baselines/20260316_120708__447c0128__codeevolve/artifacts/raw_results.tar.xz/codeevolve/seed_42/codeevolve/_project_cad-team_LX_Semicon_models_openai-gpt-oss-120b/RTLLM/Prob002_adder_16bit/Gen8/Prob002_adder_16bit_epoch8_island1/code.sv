// 8‑bit combinational full adder
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] y,
    output wire       Co
);
    // One‑line combinational addition; synthesizers will infer a ripple/carry‑lookahead structure
    assign {Co, y} = a + b + Cin;
endmodule

// 16‑bit full adder built from two 8‑bit adders
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    wire c_mid; // Carry between the low and high 8‑bit blocks

    // Lower 8 bits
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (c_mid)
    );

    // Upper 8 bits
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (c_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule