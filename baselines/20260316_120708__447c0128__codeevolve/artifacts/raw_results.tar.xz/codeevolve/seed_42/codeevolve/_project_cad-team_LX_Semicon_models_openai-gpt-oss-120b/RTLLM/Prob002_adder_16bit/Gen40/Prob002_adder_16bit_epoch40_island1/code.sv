`timescale 1ns/1ps

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (concise arithmetic implementation)
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Compute 9‑bit result: a + b + Cin
    logic [8:0] result;
    assign result = a + b + Cin;
    assign sum    = result[7:0];
    assign Cout   = result[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry from lower byte to upper byte
    logic carry_low;

    // Lower 8‑bit slice (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit slice (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule