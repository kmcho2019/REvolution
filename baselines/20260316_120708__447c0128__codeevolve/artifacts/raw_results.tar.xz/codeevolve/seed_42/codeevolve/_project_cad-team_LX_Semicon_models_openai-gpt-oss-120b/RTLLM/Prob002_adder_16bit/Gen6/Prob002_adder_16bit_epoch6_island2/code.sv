// 8‑bit combinational adder used as a building block
module adder_8bit (
    input  [7:0] a,
    input  [7:0] b,
    input        Cin,
    output [7:0] y,
    output       Co
);
    // Perform addition and capture the carry out
    assign {Co, y} = a + b + Cin;
endmodule

// 16‑bit full adder composed of two 8‑bit adders
module adder_16bit (
    input  [15:0] a,
    input  [15:0] b,
    input         Cin,
    output [15:0] y,
    output        Co
);
    wire carry_low;

    // Lower 8‑bit slice
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_low)
    );

    // Upper 8‑bit slice, using carry from lower slice
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule