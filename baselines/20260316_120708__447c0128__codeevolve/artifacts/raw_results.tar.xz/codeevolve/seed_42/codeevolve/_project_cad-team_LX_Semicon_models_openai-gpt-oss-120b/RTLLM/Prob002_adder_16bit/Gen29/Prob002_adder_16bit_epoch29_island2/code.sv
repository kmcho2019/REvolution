`default_nettype none

// ---------------------------------------------------------------
// 8‑bit ripple‑free adder inferred from vector addition
// ---------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // 9‑bit sum captures carry‑out in bit 8
    logic [8:0] sum;
    assign sum = a + b + Cin;
    assign y   = sum[7:0];
    assign Co  = sum[8];
endmodule

// ---------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders as required
// ---------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between the lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule