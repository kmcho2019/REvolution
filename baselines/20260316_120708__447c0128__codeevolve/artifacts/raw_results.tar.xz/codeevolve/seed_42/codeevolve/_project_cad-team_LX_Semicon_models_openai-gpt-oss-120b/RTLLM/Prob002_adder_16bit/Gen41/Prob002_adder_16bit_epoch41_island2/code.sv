`default_nettype none

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (optimized reuse of propagate bits)
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Propagate and generate vectors
    logic [7:0] p; // a ^ b
    logic [7:0] g; // a & b
    assign p = a ^ b;
    assign g = a & b;

    // Carry chain (c[0] is Cin, c[8] is final carry out)
    logic [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : BIT
            // Carry for next stage: generate or (propagate & carry_in)
            assign c[i+1] = g[i] | (p[i] & c[i]);
            // Sum bit uses propagate xor carry_in
            assign y[i]   = p[i] ^ c[i];
        end
    endgenerate

    assign Co = c[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between the lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule