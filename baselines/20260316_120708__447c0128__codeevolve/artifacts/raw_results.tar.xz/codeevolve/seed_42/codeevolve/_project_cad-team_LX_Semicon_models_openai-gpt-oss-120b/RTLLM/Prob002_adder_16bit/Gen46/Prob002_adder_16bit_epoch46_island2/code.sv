// ===============================================================
// 8‑bit Carry‑Lookahead Adder (CLA)
// ===============================================================
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       cin,
    output logic [7:0] sum,
    output logic       cout
);
    // Propagate and Generate signals for each bit
    logic [7:0] p;   // propagate = a ^ b
    logic [7:0] g;   // generate  = a & b
    // Carry chain (one extra bit for final carry)
    logic [8:0] c;

    assign c[0] = cin;
    assign p = a ^ b;
    assign g = a & b;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : gen_cla
            // Carry out for bit i
            assign c[i+1] = g[i] | (p[i] & c[i]);
            // Sum bit i
            assign sum[i] = p[i] ^ c[i];
        end
    endgenerate

    assign cout = c[8];
endmodule

// ===============================================================
// 16‑bit Full Adder built from two 8‑bit CLA blocks
// ===============================================================
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper 8‑bit blocks
    logic carry_mid;

    // Lower 8‑bit adder (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .cin (Cin),
        .sum (y[7:0]),
        .cout(carry_mid)
    );

    // Upper 8‑bit adder (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .cin (carry_mid),
        .sum (y[15:8]),
        .cout(Co)
    );
endmodule