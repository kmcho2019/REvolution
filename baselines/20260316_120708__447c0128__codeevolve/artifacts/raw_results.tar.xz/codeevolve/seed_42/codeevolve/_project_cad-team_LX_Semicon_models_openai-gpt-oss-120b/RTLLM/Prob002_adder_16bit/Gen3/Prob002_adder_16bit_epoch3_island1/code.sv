`timescale 1ns/1ps

// 8‑bit full adder (combinational)
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    logic [8:0] full_sum;
    assign full_sum = {1'b0, a} + {1'b0, b} + Cin;
    assign sum  = full_sum[7:0];
    assign Cout = full_sum[8];
endmodule

// 16‑bit full adder built from two 8‑bit adders
module adder_16bit (
    a,
    b,
    Cin,
    y,
    Co
);
    input  logic [15:0] a;
    input  logic [15:0] b;
    input  logic        Cin;
    output logic [15:0] y;
    output logic        Co;

    // Lower 8‑bit slice
    logic [7:0] sum_low;
    logic       carry_low;
    // Upper 8‑bit slice
    logic [7:0] sum_high;
    logic       carry_high;

    // Instantiate lower‑half adder
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (sum_low),
        .Cout(carry_low)
    );

    // Instantiate upper‑half adder
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (sum_high),
        .Cout(carry_high)
    );

    assign y  = {sum_high, sum_low};
    assign Co = carry_high;
endmodule