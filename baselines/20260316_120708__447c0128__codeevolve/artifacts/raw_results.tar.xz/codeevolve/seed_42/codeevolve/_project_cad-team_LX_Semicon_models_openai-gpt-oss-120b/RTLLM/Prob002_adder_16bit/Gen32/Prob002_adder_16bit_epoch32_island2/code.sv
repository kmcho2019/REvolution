`default_nettype none

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder (gate‑level, shared propagate/generate)
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       cin,
    output logic [7:0] sum,
    output logic       cout
);
    // Propagate and generate vectors
    logic [7:0] p; // a XOR b
    logic [7:0] g; // a AND b
    assign p = a ^ b;
    assign g = a & b;

    // Carry chain (9 bits, carry[0] is cin)
    logic [8:0] carry;
    assign carry[0] = cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : bit_block
            // Sum bit
            assign sum[i] = p[i] ^ carry[i];
            // Carry out for next stage
            assign carry[i+1] = g[i] | (p[i] & carry[i]);
        end
    endgenerate

    assign cout = carry[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between lower and upper halves
    logic carry_mid;

    // Lower 8‑bit block
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .cin (Cin),
        .sum (y[7:0]),
        .cout(carry_mid)
    );

    // Upper 8‑bit block
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .cin (carry_mid),
        .sum (y[15:8]),
        .cout(Co)
    );
endmodule