`timescale 1ns/1ps
`default_nettype none

// -------------------------------------------------------------
// 1‑bit full‑adder cell (combinational)
// -------------------------------------------------------------
module full_adder (
    input  wire a,
    input  wire b,
    input  wire Cin,
    output wire sum,
    output wire Cout
);
    // Sum = a ^ b ^ Cin
    assign sum  = a ^ b ^ Cin;
    // Carry‑out = generate or propagate & carry
    assign Cout = (a & b) | (a & Cin) | (b & Cin);
endmodule

// -------------------------------------------------------------
// 8‑bit ripple‑carry adder built from full_adder cells
// -------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Internal carry chain (c[0] is the input carry)
    wire [7:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : FA_CHAIN
            if (i == 7) begin
                // The most‑significant cell drives the top‑level Cout directly
                full_adder u_fa (
                    .a   (a[i]),
                    .b   (b[i]),
                    .Cin (c[i]),
                    .sum (sum[i]),
                    .Cout(Cout)
                );
            end else begin
                // Intermediate cells produce the next carry in the chain
                wire carry_next;
                full_adder u_fa (
                    .a   (a[i]),
                    .b   (b[i]),
                    .Cin (c[i]),
                    .sum (sum[i]),
                    .Cout(carry_next)
                );
                assign c[i+1] = carry_next;
            end
        end
    endgenerate
endmodule

// -------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit adders
// -------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Carry between lower and upper byte
    wire carry_mid;

    // Lower byte (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper byte (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule