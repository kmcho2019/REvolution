`timescale 1ns/1ps
`default_nettype none

// ------------------------------------------------------------------
// Parameterizable N‑bit ripple‑carry adder (gate‑level style)
// ------------------------------------------------------------------
module adder_nbit #(
    parameter int WIDTH = 8
) (
    input  logic [WIDTH-1:0] a,
    input  logic [WIDTH-1:0] b,
    input  logic             Cin,
    output logic [WIDTH-1:0] sum,
    output logic             Cout
);
    // Carry chain: carry[0] is the incoming carry, carry[WIDTH] is the final carry
    logic [WIDTH:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < WIDTH; i = i + 1) begin : BIT
            // Sum bit
            assign sum[i] = a[i] ^ b[i] ^ carry[i];
            // Carry for next stage: g | (p & c)
            assign carry[i+1] = (a[i] & b[i]) | ((a[i] ^ b[i]) & carry[i]);
        end
    endgenerate

    assign Cout = carry[WIDTH];
endmodule

// ------------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adder_nbit instances
// ------------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_nbit #(.WIDTH(8)) u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_nbit #(.WIDTH(8)) u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule