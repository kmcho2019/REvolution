`default_nettype none

// ---------------------------------------------------------------
// 8‑bit ripple‑carry adder (gate‑level, propagate/generate style)
// ---------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Carry chain: c[0] = Cin, c[8] = final carry out
    logic [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : BIT
            // Sum bit: a ^ b ^ carry_in
            assign y[i] = a[i] ^ b[i] ^ c[i];
            // Carry out: generate OR (propagate AND carry_in)
            assign c[i+1] = (a[i] & b[i]) | ((a[i] ^ b[i]) & c[i]);
        end
    endgenerate

    assign Co = c[8];
endmodule

// ---------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders (generate loop)
// ---------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between the two 8‑bit slices
    logic carry_mid;

    genvar blk;
    generate
        // Lower 8‑bit slice (blk = 0)
        if (blk == 0) begin : LOWER
            adder_8bit u_low (
                .a   (a[7:0]),
                .b   (b[7:0]),
                .Cin (Cin),
                .y   (y[7:0]),
                .Co  (carry_mid)
            );
        end
        // Upper 8‑bit slice (blk = 1)
        if (blk == 1) begin : UPPER
            adder_8bit u_high (
                .a   (a[15:8]),
                .b   (b[15:8]),
                .Cin (carry_mid),
                .y   (y[15:8]),
                .Co  (Co)
            );
        end
    endgenerate
endmodule