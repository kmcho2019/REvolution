// ------------------------------------------------------------
// Parameterized 8‑bit ripple‑carry adder (gate‑level implementation)
// ------------------------------------------------------------
module adder_8bit #(
    parameter int WIDTH = 8
) (
    input  logic [WIDTH-1:0] a,
    input  logic [WIDTH-1:0] b,
    input  logic             Cin,
    output logic [WIDTH-1:0] sum,
    output logic             Cout
);
    // Internal carry chain (WIDTH+1 bits to hold final carry)
    logic [WIDTH:0] carry;
    assign carry[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < WIDTH; i = i + 1) begin : gen_bit
            // Sum bit: a ^ b ^ carry_in
            assign sum[i] = a[i] ^ b[i] ^ carry[i];
            // Carry out: (a & b) | (a & carry_in) | (b & carry_in)
            assign carry[i+1] = (a[i] & b[i]) | (a[i] & carry[i]) | (b[i] & carry[i]);
        end
    endgenerate

    assign Cout = carry[WIDTH];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper 8‑bit blocks
    logic carry_mid;

    // Lower 8 bits (bits 0‑7)
    adder_8bit #(.WIDTH(8)) u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8 bits (bits 8‑15)
    adder_8bit #(.WIDTH(8)) u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule