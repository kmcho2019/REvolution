`timescale 1ns/1ps

// ------------------------------------------------------------
// 4‑bit combinational full adder (uses built‑in addition)
// ------------------------------------------------------------
module adder_4bit (
    input  wire [3:0] a,
    input  wire [3:0] b,
    input  wire       Cin,
    output wire [3:0] y,
    output wire       Co
);
    // 5‑bit result: lower 4 bits are sum, MSB is carry‑out
    assign {Co, y} = a + b + Cin;
endmodule

// ------------------------------------------------------------
// 8‑bit combinational full adder built from two 4‑bit adders
// ------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] y,
    output wire       Co
);
    // Carry from the lower 4‑bit block to the upper block
    wire carry_mid;

    // Lower 4‑bit slice (bits 3:0)
    adder_4bit u_low (
        .a   (a[3:0]),
        .b   (b[3:0]),
        .Cin (Cin),
        .y   (y[3:0]),
        .Co  (carry_mid)
    );

    // Upper 4‑bit slice (bits 7:4)
    adder_4bit u_high (
        .a   (a[7:4]),
        .b   (b[7:4]),
        .Cin (carry_mid),
        .y   (y[7:4]),
        .Co  (Co)
    );
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders (as required)
// ------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Carry between the lower and upper byte
    wire carry_low;

    // Lower 8‑bit block (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_low)
    );

    // Upper 8‑bit block (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule