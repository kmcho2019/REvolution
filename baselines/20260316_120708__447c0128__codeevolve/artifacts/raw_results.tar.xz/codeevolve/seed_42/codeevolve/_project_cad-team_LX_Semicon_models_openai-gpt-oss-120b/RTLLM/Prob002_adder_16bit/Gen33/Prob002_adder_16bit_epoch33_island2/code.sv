`default_nettype none

// ====================================================================
// 1‑bit full‑adder cell (gate‑level style)
// ====================================================================
module full_adder (
    input  logic a,
    input  logic b,
    input  logic cin,
    output logic sum,
    output logic cout
);
    // Sum = a XOR b XOR cin
    assign sum = a ^ b ^ cin;
    // Carry‑out = generate OR (propagate AND cin)
    assign cout = (a & b) | ((a ^ b) & cin);
endmodule

// ====================================================================
// 8‑bit ripple‑carry adder built from full_adder cells
// ====================================================================
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] y,
    output logic       Co
);
    // Carry vector: c[0] is the incoming carry, c[8] is the final carry‑out
    logic [8:0] c;
    assign c[0] = Cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : BIT
            full_adder fa (
                .a   (a[i]),
                .b   (b[i]),
                .cin (c[i]),
                .sum (y[i]),
                .cout(c[i+1])
            );
        end
    endgenerate

    assign Co = c[8];
endmodule

// ====================================================================
// 16‑bit full adder composed of two 8‑bit adders as required
// ====================================================================
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Intermediate carry between lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .y   (y[7:0]),
        .Co  (carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .y   (y[15:8]),
        .Co  (Co)
    );
endmodule