// 8‑bit combinational adder using a single arithmetic assignment
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       cin,
    output logic [7:0] sum,
    output logic       cout
);
    // The Verilog '+' operator infers a ripple‑carry adder; the concatenation captures the final carry out.
    assign {cout, sum} = a + b + cin;
endmodule

// 16‑bit adder composed of two 8‑bit adders
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper 8‑bit blocks
    logic carry_low;

    // Lower 8‑bit slice
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .cin (Cin),
        .sum (y[7:0]),
        .cout(carry_low)
    );

    // Upper 8‑bit slice
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .cin (carry_low),
        .sum (y[15:8]),
        .cout(Co)
    );
endmodule