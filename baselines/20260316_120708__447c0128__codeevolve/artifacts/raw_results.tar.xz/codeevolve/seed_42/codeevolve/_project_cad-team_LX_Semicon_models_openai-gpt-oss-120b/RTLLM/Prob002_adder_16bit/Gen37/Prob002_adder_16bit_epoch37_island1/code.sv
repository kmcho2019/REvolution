`timescale 1ns/1ps

// ------------------------------------------------------------
// 1‑bit full adder (pure combinational)
// ------------------------------------------------------------
module full_adder (
    input  wire a,
    input  wire b,
    input  wire Cin,
    output wire sum,
    output wire Cout
);
    // Sum = a ^ b ^ Cin
    assign sum  = a ^ b ^ Cin;
    // Carry = generate OR propagate
    assign Cout = (a & b) | (a & Cin) | (b & Cin);
endmodule

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder built from full_adder cells
// ------------------------------------------------------------
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Internal carry signals between bits
    wire [7:0] carry;

    // Bit 0 uses external Cin
    full_adder u0 (
        .a   (a[0]),
        .b   (b[0]),
        .Cin (Cin),
        .sum (sum[0]),
        .Cout(carry[0])
    );

    // Bits 1‑7 generated in a loop
    genvar i;
    generate
        for (i = 1; i < 8; i = i + 1) begin : gen_bits
            full_adder ua (
                .a   (a[i]),
                .b   (b[i]),
                .Cin (carry[i-1]),
                .sum (sum[i]),
                .Cout(carry[i])
            );
        end
    endgenerate

    // Final carry out of the 8‑bit block
    assign Cout = carry[7];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder composed of two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Carry from lower byte to upper byte
    wire carry_low;

    // Lower 8‑bit block (bits 7:0)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit block (bits 15:8)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule