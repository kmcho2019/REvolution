`timescale 1ns/1ps
`default_nettype none

// ------------------------------------------------------------
// 8‑bit ripple‑carry adder implemented via a carry‑vector function
// ------------------------------------------------------------
module adder_8bit (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic       Cin,
    output logic [7:0] sum,
    output logic       Cout
);
    // Function that returns the full carry chain c[0]..c[8]
    function automatic logic [8:0] carry_chain (
        input logic [7:0] aa,
        input logic [7:0] bb,
        input logic       cc
    );
        logic [8:0] c;
        c[0] = cc;
        for (int i = 0; i < 8; i++) begin
            // generate = a & b, propagate = a ^ b
            c[i+1] = (aa[i] & bb[i]) | ((aa[i] ^ bb[i]) & c[i]);
        end
        return c;
    endfunction

    // Compute the carry vector once
    logic [8:0] c_vec;
    assign c_vec = carry_chain(a, b, Cin);

    // Sum bits using the computed carries
    assign sum  = a ^ b ^ c_vec[7:0];
    assign Cout = c_vec[8];
endmodule

// ------------------------------------------------------------
// 16‑bit full adder built from two 8‑bit adders
// ------------------------------------------------------------
module adder_16bit (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic        Cin,
    output logic [15:0] y,
    output logic        Co
);
    // Carry between the lower and upper byte
    logic carry_mid;

    // Lower 8‑bit slice (bits 0‑7)
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_mid)
    );

    // Upper 8‑bit slice (bits 8‑15)
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule