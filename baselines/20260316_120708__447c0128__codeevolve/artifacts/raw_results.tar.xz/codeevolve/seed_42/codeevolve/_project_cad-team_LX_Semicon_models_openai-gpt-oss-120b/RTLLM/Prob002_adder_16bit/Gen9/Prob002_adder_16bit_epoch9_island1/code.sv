// 8‑bit combinational adder
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // Sum bits
    assign sum = a ^ b ^ Cin; // XOR works for vector, Cin will be broadcast
    // Carry‑out calculation for each bit, then reduce to final carry
    // Using the classic carry formula for the most‑significant bit
    assign Cout = (a[7] & b[7]) | (a[7] & Cin) | (b[7] & Cin);
endmodule

// 16‑bit full adder built from two 8‑bit adders
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    wire [7:0] sum_lo;
    wire [7:0] sum_hi;
    wire       carry_mid;

    // Lower 8 bits
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (sum_lo),
        .Cout(carry_mid)
    );

    // Upper 8 bits, using carry from lower block
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_mid),
        .sum (sum_hi),
        .Cout(Co)
    );

    assign y = {sum_hi, sum_lo};
endmodule