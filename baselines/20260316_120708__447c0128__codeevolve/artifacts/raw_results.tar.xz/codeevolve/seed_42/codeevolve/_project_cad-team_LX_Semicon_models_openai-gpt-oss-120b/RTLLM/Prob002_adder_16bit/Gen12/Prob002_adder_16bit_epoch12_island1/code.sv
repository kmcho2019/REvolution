`timescale 1ns/1ps
`default_nettype none

// 8‑bit combinational adder
module adder_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire       Cin,
    output wire [7:0] sum,
    output wire       Cout
);
    // One vector addition implements the full adder logic
    assign {Cout, sum} = a + b + Cin;
endmodule

// 16‑bit full adder built from two 8‑bit adders
module adder_16bit (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire        Cin,
    output wire [15:0] y,
    output wire        Co
);
    // Carry from the lower byte
    wire carry_low;

    // Lower 8‑bit addition directly drives the lower half of the result
    adder_8bit u_low (
        .a   (a[7:0]),
        .b   (b[7:0]),
        .Cin (Cin),
        .sum (y[7:0]),
        .Cout(carry_low)
    );

    // Upper 8‑bit addition uses the carry out of the lower adder
    adder_8bit u_high (
        .a   (a[15:8]),
        .b   (b[15:8]),
        .Cin (carry_low),
        .sum (y[15:8]),
        .Cout(Co)
    );
endmodule