# Pareto Front Validation

- valid: `True`
- failure_count: `0`
- problem_invalid_count: `0`
- acceptance_error_count: `0`
- max_front_size_seen: `3`

## Problems

- `RTLLM/Prob045_alu`: valid=True, members=13, max_front=2
- `RTLLM/Prob041_traffic_light`: valid=True, members=8, max_front=1
- `RTLLM/Prob015_multi_pipe_8bit`: valid=True, members=13, max_front=3
